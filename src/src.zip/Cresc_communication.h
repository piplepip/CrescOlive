class Cresc_com_id_input
{
private:
    /* data */
public:
    Cresc_com_id_input(/* args */);
    ~Cresc_com_id_input();
};

Cresc_com_id_input::Cresc_com_id_input(/* args */)
{
}

Cresc_com_id_input::~Cresc_com_id_input()
{
}

class Cresc_com_id_output
{
private:
    /* data */
public:
    Cresc_com_id_output(/* args */);
    ~Cresc_com_id_output();
};

Cresc_com_id_output::Cresc_com_id_output(/* args */)
{
}

Cresc_com_id_output::~Cresc_com_id_output()
{
}

class Cresc_com_data_input
{
private:
    /* data */
public:
    Cresc_com_data_input(/* args */);
    ~Cresc_com_data_input();
};

Cresc_com_data_input::Cresc_com_data_input(/* args */)
{
}

Cresc_com_data_input::~Cresc_com_data_input()
{
}

class Cresc_com_data_output
{
private:
    /* data */
public:
    Cresc_com_data_output(/* args */);
    ~Cresc_com_data_output();
};

Cresc_com_data_output::Cresc_com_data_output(/* args */)
{
}

Cresc_com_data_output::~Cresc_com_data_output()
{
}
