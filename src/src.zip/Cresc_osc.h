#include <OSCMessage.h>
#include <SLIPEncodedUSBSerial.h>
#include "Cresc_config.h"

Cresc_config config;

SLIPEncodedUSBSerial SLIPSerial(thisBoardsSerialUSB);

class Cresc_osc
{
public:

    OSCMessage button[config.buttons.nr];
    OSCMessage encoder[config.encoder.nr];
    OSCMessage encoderButton[config.encoder.nr];
    OSCMessage joystickX[config.joysticks.nr];
    OSCMessage joystickY[config.joysticks.nr];

    Cresc_osc();
    ~Cresc_osc();

    //Output

    void initializeOutput();
    void send(int controllerNr, char controllerType, int value); //e = encoder, b = button, j = joystick
};

//using namespace std;

Cresc_osc::Cresc_osc()
{
    initializeOutput();
}

Cresc_osc::~Cresc_osc()
{
}

void Cresc_osc::initializeOutput()
{
    #ifndef DEBUG
    SLIPSerial.begin(9600);
    #endif
    //Output

    for (int i = 0; i < config.buttons.nr; i++)
    {
        button[i].setAddress(config.osc.buttonAdress[i]);
    }
    for (int i = 0; i < config.encoder.nr; i++)
    {
        encoder[i].setAddress(config.osc.encoderAdress.send[i]);
    }
    for (int i = 0; i < config.encoder.nr; i++)
    {
        encoderButton[i].setAddress(config.osc.encoderAdress.button[i]);
    }
    for (int i = 0; i < config.joysticks.nr; i++)
    {
        joystickX[i].setAddress(config.osc.joystickAdress.x[i]);
    }
    for (int i = 0; i < config.joysticks.nr; i++)
    {
        joystickY[i].setAddress(config.osc.joystickAdress.y[i]);
    }
}

void Cresc_osc::send(int controllerNr, char controllerType, int value)
{
    switch (controllerType)
    {
    case 'b':
        button[controllerNr].add((int32_t)value);
        SLIPSerial.beginPacket();
        button[controllerNr].send(SLIPSerial);
        SLIPSerial.endPacket();
        button[controllerNr].empty();
        break;
        
    case 'e':
        encoder[controllerNr].add((int32_t)value);
        SLIPSerial.beginPacket();
        encoder[controllerNr].send(SLIPSerial);
        SLIPSerial.endPacket();
        encoder[controllerNr].empty();
        break;

    case 'p':
        encoderButton[controllerNr].add((int32_t)value);
        SLIPSerial.beginPacket();
        encoderButton[controllerNr].send(SLIPSerial);
        SLIPSerial.endPacket();
        encoderButton[controllerNr].empty();
        break;

    case 'x':
        joystickX[controllerNr].add((int32_t)value);
        SLIPSerial.beginPacket();
        joystickX[controllerNr].send(SLIPSerial);
        SLIPSerial.endPacket();
        joystickX[controllerNr].empty();
        break;
        
    case 'y':
        joystickY[controllerNr].add((int32_t)value);
        SLIPSerial.beginPacket();
        joystickY[controllerNr].send(SLIPSerial);
        SLIPSerial.endPacket();
        joystickY[controllerNr].empty();
        break;
    
    default:
        break;
    }
}
