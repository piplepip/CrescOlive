class Cresc_output_ledRings
{
public:
    Cresc_output_ledRings();
    ~Cresc_output_ledRings();
};

Cresc_output_ledRings::Cresc_output_ledRings()
{
}

Cresc_output_ledRings::~Cresc_output_ledRings()
{
}
