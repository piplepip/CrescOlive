class Cresc_vars
{
public:
    

    Cresc_vars();
    ~Cresc_vars();
};

Cresc_vars::Cresc_vars()
{
}

Cresc_vars::~Cresc_vars()
{
}
